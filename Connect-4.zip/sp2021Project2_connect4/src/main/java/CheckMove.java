
public class CheckMove {

    static String horizontal="";
    static String vertical="";
    static String diagonal="";
	public static int didWin(Integer[][] board) {
	    final int HEIGHT = board.length;
	    final int WIDTH = board[0].length;
	    final int EMPTY_SLOT = 0;
	    
	    for (int r = 0; r < HEIGHT; r++) { // iterate rows, bottom to top
	        for (int c = 0; c < WIDTH; c++) { // iterate columns, left to right
	            int player = board[r][c];
	            if (player == EMPTY_SLOT)
	                continue; // don't check empty slots

	            if (c + 3 < WIDTH &&
	                player == board[r][c+1] && // look right
	                player == board[r][c+2] &&
	                player == board[r][c+3]){

	            	horizontal=r+":"+c+","+r+":"+(c+1)+","+r+":"+(c+2)+","+r+":"+(c+3);
	            	
	            	return player;
	                
	            }
	            if (r + 3 < HEIGHT) {
	                if (player == board[r+1][c] && // look up
	                    player == board[r+2][c] &&
	                    player == board[r+3][c]){

		            	vertical=r+":"+c+","+(r+1)+":"+c+","+(r+2)+":"+c+","+(r+3)+":"+c;
	                	return player;
	                
	                }
	                if (c + 3 < WIDTH &&
	                    player == board[r+1][c+1] && // look up & right
	                    player == board[r+2][c+2] &&
	                    player == board[r+3][c+3]){
	                    
	                	diagonal=r+":"+c+","+(r+1)+":"+(c+1)+","+(r+2)+":"+(c+2)+","+(r+3)+":"+(c+3);
	                	return player;
	                    }
	                if (c - 3 >= 0 &&
	                    player == board[r+1][c-1] && // look up & left
	                    player == board[r+2][c-2] &&
	                    player == board[r+3][c-3]){
	                	diagonal=r+":"+c+","+(r+1)+":"+(c-1)+","+(r+2)+":"+(c-2)+","+(r+3)+":"+(c-3);
	                	return player;
	                	}
	            }
	        }
	    }
	    return EMPTY_SLOT; // no winner found
	}
	public static Boolean isMoveValid(Integer[][] board, int x, int y){
		if(y<5&&board[x][y]==0){
			if(board[x][y+1]!=0)
				return true;
		}else if(y==5&&board[x][y]==0){
			return true;
		}else{
			return false;
		}
		return false;
	}
}
