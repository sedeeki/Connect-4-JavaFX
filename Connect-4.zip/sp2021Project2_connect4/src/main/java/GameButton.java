import java.util.List;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.text.Text;

public class GameButton extends Button implements EventHandler<ActionEvent>{
	private JavaFXTemplate javaFxTemplate;
	private TextArea playerLog;
	private Text playerTurnText;
	private List<String> playerMoves;
	private Integer posX, posY;
	private Integer[][] board;
	private List<String> playerColors;
	private int playerTurn=0;

	public GameButton(JavaFXTemplate javaFXTemplate, int x, int y){
		this.javaFxTemplate= javaFXTemplate;

		this.playerLog=javaFxTemplate.playerLog;
		this.playerTurnText=javaFxTemplate.playerTurnText;
		this.playerMoves=javaFxTemplate.playerMoves;
		this.board= javaFxTemplate.board;
		this.playerColors=javaFxTemplate.playerColors;
		this.posX=x;
		this.posY=y;

		setOnAction(this);
		setMinHeight(80);
		setMinWidth(80);
	}

	@Override
	public void handle(ActionEvent event) {
		Integer index=-1;

		StringBuilder log= new StringBuilder();
		try {
			if(CheckMove.isMoveValid(board, posX, posY)){
				if(playerMoves.size()!=0){
					index= playerMoves.size()-1;
					log.append(playerLog.getText());
					
					if(playerMoves.get(index)=="p1"){
						playerTurn=2;
						setStyle(playerColors.get(1));
						log.append("\nPlayer 2 move to "+posX+","+posY);
						playerLog.setText(log.toString());
						playerMoves.add("p2");
						board[posX][posY]=2;
						playerTurnText.setText("Player 1 Turn");
					}else{
						setStyle(playerColors.get(0));
						log.append("\nPlayer 1 move to "+posX+","+posY);
						playerLog.setText(log.toString());
						playerMoves.add("p1");
						board[posX][posY]=1;
						playerTurnText.setText("Player 2 Turn");
					}
					
					
				}else{ 
					log.append(playerLog.getText());
					setStyle(playerColors.get(0));
					playerLog.setText("Player 1 move to "+posX+","+posY);
					playerMoves.add("p1");
					playerTurnText.setText("Player 2 Turn");
					board[posX][posY]=1;
				}
	
				javaFxTemplate.selectedButtons.add(this);
				int whichPlayerWin=CheckMove.didWin(board);
				if(whichPlayerWin!=0){
					String pattern="";
					if(!CheckMove.horizontal.isEmpty())
						pattern=CheckMove.horizontal;
	
					if(!CheckMove.vertical.isEmpty())
						pattern=CheckMove.vertical;
	
					if(!CheckMove.diagonal.isEmpty())
						pattern=CheckMove.diagonal;
					
					log.append("\nPlayer "+whichPlayerWin+" Win!");
					playerLog.setText(log.toString());
					javaFxTemplate.updateGameResults(pattern,whichPlayerWin);
	//				javaFxTemplate.gameOverScene("Player "+whichPlayerWin+" Wins!");
				}
				setDisable(true);
				setOpacity(1.0);
			}else{
				log.append(playerLog.getText());
				if(playerMoves.get(playerMoves.size()-1)=="p1"){
				log.append("\nPlayer 2 moved to "+posX+","+posY+". This is NOT a valid move. Player 2 pick again.");
				}else{
				log.append("\nPlayer 1 moved to "+posX+","+posY+". This is NOT a valid move. Player 1 pick again.");		
				}
				playerLog.setText(log.toString());
			}
			 playerLog.setScrollTop(Double.MAX_VALUE);
		} catch (Exception e) {
			System.out.println("Wrong click");
		}
	}
	public void resetButton(){
		
	}
	
	public void updateButtonStyle(){
		if(playerTurn==2){
			setStyle(playerColors.get(1));
		}else{
			setStyle(playerColors.get(0));
		}
	}
	
	public Integer getPosX() {
		return posX;
	}

	public void setPosX(Integer posX) {
		this.posX = posX;
	}

	public Integer getPosY() {
		return posY;
	}

	public void setPosY(Integer posY) {
		this.posY = posY;
	}
	
}
