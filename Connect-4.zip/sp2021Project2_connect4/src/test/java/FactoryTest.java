import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;



class FactoryTest {
	
	
	static CoffeeFactory cf;
	
	
	public void initialize() {
		cf = new CoffeeFactory();
	}
	
	
	
	@Test
	public void test1() {
		initialize();
		assertEquals(new ColdBrewCoffee().getClass(), CoffeeFactory.getCoffee("cb").getClass());
	}
	
	@Test
	public void test2() {
		initialize();
		assertEquals(new LightRoastCoffee().getClass(), CoffeeFactory.getCoffee("lr").getClass());
	}
	
	@Test
	public void test3() {
		initialize();
		assertEquals(new DarkRoastCoffee().getClass(), CoffeeFactory.getCoffee("dr").getClass());
	}
	
	@Test
	public void test4() {
		initialize();
		assertEquals(new LightRoastCoffee().getClass(), CoffeeFactory.getCoffee("aa").getClass());
	}
	
	@Test
	public void test5() {
		initialize();
		ArrayList <Coffee> coffees = new ArrayList <Coffee> ();
		coffees.add(CoffeeFactory.getCoffee("cb"));
		coffees.add(CoffeeFactory.getCoffee("lr"));
		coffees.add(CoffeeFactory.getCoffee("dr"));
		coffees.add(CoffeeFactory.getCoffee("aa"));
		ArrayList <Coffee> actualCoffees = new ArrayList <Coffee> ();
		actualCoffees.add(new ColdBrewCoffee());
		actualCoffees.add(new LightRoastCoffee());
		actualCoffees.add(new DarkRoastCoffee());
		actualCoffees.add(new LightRoastCoffee());
		int count = 0;
		for (int i = 0; i < 4; i++)
			if (coffees.get(i).getClass().equals(actualCoffees.get(i).getClass()))
				count++;
		assertEquals(4,count);
	}
	
	
}
