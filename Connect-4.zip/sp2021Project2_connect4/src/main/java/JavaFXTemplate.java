

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

public class JavaFXTemplate extends Application {
	
	public TextArea playerLog;
	public Text playerTurnText;
	private VBox vbox;
	public List<String> playerMoves= new ArrayList<String>();
	public Integer[][] board = new Integer[7][6];
	public List<String> playerColors= new ArrayList<String>();
	private boolean originalTheme=false;
	private boolean theme1=false;
	private boolean theme2=true;
	private List<GameButton> gridButtons;
	public List<GameButton> selectedButtons=new ArrayList<>();
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}
	private Stage primaryStage;

	//feel free to remove the starter code from this method
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		this.primaryStage=primaryStage;
		primaryStage.setTitle("Welcome to JavaFX");
//		gameScene();
		welcomeScene();
		primaryStage.show();
	}
	public void welcomeScene(){
		Text title= new Text("Connect Four Game");
		title.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.ITALIC, 30));
		title.setFill(Color.WHITE);
		Button playGame= new Button("Play Game");
		playGame.setPadding(new Insets(20));
		playGame.setStyle("-fx-background-color: #4cd137;");
		playGame.setOnAction(event->{
			try {
				gameScene();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		Region topSpring = new Region();
		Region bottomSpring = new Region();
		/*Scene scene = new Scene(VBoxBuilder.create()
		        .children(topSpring, title, playGame ,bottomSpring)
		        .alignment(Pos.CENTER).spacing(20).style("-fx-background-color: #00a8ff;")
		        .padding(new Insets(10))
		        .build(), 600, 600);
		*/
		VBox vBox = new VBox();
		vBox.setAlignment(Pos.CENTER);
		vBox.setSpacing(20);
		vBox.setStyle("-fx-background-color: #00a8ff;");
		vBox.setPadding(new Insets(10));
		vBox.getChildren().add(topSpring);
		vBox.getChildren().add(title);
		vBox.getChildren().add(playGame);
		vBox.getChildren().add(bottomSpring);
		Scene scene = new Scene(vBox);
		
		VBox.setVgrow(topSpring, Priority.ALWAYS);
		VBox.setVgrow(bottomSpring, Priority.ALWAYS);
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	public void gameScene() throws FileNotFoundException{
		vbox= new VBox();

		vbox.getChildren().add(getMenuBar());
		vbox.getChildren().add(getPlayerLogArea());
		vbox.getChildren().add(getGameBoard());
		setTheme();
		
		playerMoves.clear();
		selectedButtons.clear();
		for(int i=0;i<6;i++){
			for(int x=0;x<7;x++)
				board[x][i]=0;
		}

		vbox.setPadding(new Insets(10));
		Scene scene = new Scene(vbox);
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	public void gameOverScene(String message){
		Text text= new Text(message);
		text.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20)); 
		Button newGame= new Button("New Game");
		Button exitGame= new Button("Exit Game");
		newGame.setPadding(new Insets(20));
		newGame.setStyle("-fx-background-color: #4cd137;");

		exitGame.setPadding(new Insets(20));
		exitGame.setStyle("-fx-background-color: #e84118;");
		HBox hbox= new HBox(newGame,exitGame);
		
		newGame.setOnAction(event->{
			try {
				gameScene();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		exitGame.setOnAction(event->{
			System.exit(0);
		});
		
		vbox.getChildren().add(text);
		vbox.getChildren().add(hbox);
		Region topSpring = new Region();
		Region bottomSpring = new Region();
		/*Scene scene = new Scene(VBoxBuilder.create()
		        .children(topSpring, text, newGame,exitGame,bottomSpring)
		        .alignment(Pos.CENTER).spacing(20).style("-fx-background-color: #00a8ff;")
		        .padding(new Insets(10))
		        .build(), 600, 600);*/
		VBox vBox = new VBox();
		vBox.setAlignment(Pos.CENTER);
		vBox.setSpacing(20);
		vBox.setStyle("-fx-background-color: #00a8ff;");
		vBox.setPadding(new Insets(10));
		vBox.getChildren().add(topSpring);
		vBox.getChildren().add(text);
		vBox.getChildren().add(newGame);
		vBox.getChildren().add(exitGame);
		vBox.getChildren().add(bottomSpring);
		Scene scene = new Scene(vBox);
		VBox.setVgrow(topSpring, Priority.ALWAYS);
		VBox.setVgrow(bottomSpring, Priority.ALWAYS);
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	
	public MenuBar getMenuBar(){
		Menu playMenu = new Menu("Game Play Menu");
		Menu themesMenu= new Menu("Themes Menu");
		Menu optionsMenu= new Menu("Options Menu");
		
		MenuItem reverseMove= new MenuItem("reverse move");
		MenuItem originalTheme= new MenuItem("Original Theme");
		MenuItem theme1= new MenuItem("Harry Potter Theme");
		MenuItem theme2= new MenuItem("Dragon ball Theme");
		MenuItem howToPlay= new MenuItem("How To Play");
		MenuItem newGame= new MenuItem("New Game");
		MenuItem exit= new MenuItem("Exit");
		howToPlay.setOnAction(event->{
			getHowToPlayDialog().showAndWait();
		});
		newGame.setOnAction(event->{
			try {
				gameScene();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		
		exit.setOnAction(event->{
			System.exit(0);
		});
		reverseMove.setOnAction(event->{
			
			int lastMove= playerMoves.size()-1;
			if(lastMove>-1){
			playerMoves.remove(lastMove);
			GameButton button = selectedButtons.get(lastMove);
			button.setStyle(null);
			button.setDisable(false);
			board[button.getPosX()][button.getPosY()]=0;
			selectedButtons.remove(lastMove);
			updatePlayerText();
			}
		});
		
		
		originalTheme.setOnAction(event->{
			this.originalTheme=true;
			this.theme1=false;
			this.theme2=false;
			try {
				this.setTheme();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			selectedButtons.forEach(button->{
				button.updateButtonStyle();
			});
		});
		theme1.setOnAction(event->{
			this.originalTheme=false;
			this.theme1=true;
			this.theme2=false;
			try {
				this.setTheme();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			selectedButtons.forEach(button->{
				button.updateButtonStyle();
			});
		});
		theme2.setOnAction(event->{
			this.originalTheme=false;
			this.theme1=false;
			this.theme2=true;
			try {
				this.setTheme();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			selectedButtons.forEach(button->{
				button.updateButtonStyle();
			});
		});
		
		playMenu.getItems().add(reverseMove);
		
		themesMenu.getItems().add(originalTheme);
		themesMenu.getItems().add(theme1);
		themesMenu.getItems().add(theme2);
		
		optionsMenu.getItems().add(howToPlay);
		optionsMenu.getItems().add(newGame);
		optionsMenu.getItems().add(exit);
		
		MenuBar menuBar = new MenuBar();
		
		menuBar.getMenus().add(playMenu);
		menuBar.getMenus().add(themesMenu);
		menuBar.getMenus().add(optionsMenu);
		
		return menuBar;
	}
	public GridPane getGameBoard(){
		gridButtons=new ArrayList<>();
		GridPane pane= new GridPane();
		pane.setHgap(10);
		pane.setVgap(10);

		pane.setPadding(new Insets(10));
		for(int i=0; i<6;i++){
			for(int u=0; u<7;u++){
				GameButton button= new GameButton(this,u,i);
				gridButtons.add(button);
				pane.add(button, u, i);
			}
		}
		return pane;
	}
	
	public HBox getPlayerLogArea(){
		playerLog=new TextArea();
		playerTurnText= new Text("Player 1 Turn");
		playerTurnText.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20)); 
	       
		HBox hBox = new HBox(playerLog,playerTurnText);
		hBox.setPadding(new Insets(10));
		return hBox;
	} 
	
	public void setTheme() throws FileNotFoundException{
		if(originalTheme){
			playerColors.clear();
			playerColors.add("-fx-background-color: #3498db");
			playerColors.add("-fx-background-color: #e74c3c");
			playerTurnText.setFill(Color.WHITE);
			FileInputStream inputstream = new FileInputStream("original.jpg"); 
			BackgroundImage myBI= new BackgroundImage(new Image(inputstream),
			        BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,
			          BackgroundSize.DEFAULT);
			vbox.setBackground(new Background(myBI));
		}else if(theme1){
			playerColors.clear();
			playerColors.add("-fx-background-color: #9c1203");
			playerColors.add("-fx-background-color: #e3a000");
			playerTurnText.setFill(Color.WHITE);
			FileInputStream inputstream = new FileInputStream("harrypotter.jpg"); 
			BackgroundImage myBI= new BackgroundImage(new Image(inputstream),
			        BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,
			          BackgroundSize.DEFAULT);
			vbox.setBackground(new Background(myBI));
		}else if(theme2){
			playerColors.clear();
			playerColors.add("-fx-background-color: #00a8ff");
			playerColors.add("-fx-background-color: #fbc531");
			FileInputStream inputstream = new FileInputStream("dragonball.jpg"); 
			BackgroundImage myBI= new BackgroundImage(new Image(inputstream),
			        BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,
			          BackgroundSize.DEFAULT);
			vbox.setBackground(new Background(myBI));
			playerTurnText.setFill(Color.BLUE);
		}
	}
	public void updatePlayerText(){
		int index= playerMoves.size();
		if(index!=0){
		if(playerMoves.get(index-1)=="p1")
			playerTurnText.setText("Player 2 Turn");
		else{
			playerTurnText.setText("Player 1 Turn");
		}
		
	}else{
		playerTurnText.setText("Player 1 Turn");
	}
	}
	
	public void updateGameResults(String pattern,int player){
		System.out.println(pattern);
		String[] positions = pattern.split(",");
		System.out.println(positions.length);
		for(int i=0;i<positions.length;i++){
			System.out.println(positions[i]);
			int x= Integer.parseInt(positions[i].split(":")[0]);
			int y= Integer.parseInt(positions[i].split(":")[1]);
			selectedButtons.forEach(button->{
				if(button.getPosX()==x&&button.getPosY()==y)
					button.setText("Match");
			});
		}
		gridButtons.forEach(button->{
			button.setDisable(true);
		});
		Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(4), new EventHandler<ActionEvent>() { 

		    @Override
		    public void handle(ActionEvent event) {

				gameOverScene("Player "+player+" Wins!");
		    }
		}));
		timeline.setCycleCount(0);
		timeline.play();
	}
	
	public Dialog getHowToPlayDialog(){
		 Dialog<String> dialog = new Dialog<String>();
	      //Setting the title
	      dialog.setTitle("How To Play");
	      ButtonType type = new ButtonType("Ok", ButtonData.OK_DONE);
	      //Setting the content of the dialog
	      dialog.setContentText("1. Place the checker by clicking buttons on the grid"
	    		  				+"\n"
	    		  				+"2. Connect the checkers horizontally, vertically or Diagonally"
	    		  				+"\n"
	    		  				+"3. Player who connects first will win."
	    		  				+"\n"
	    		  				+"4. Checkers can only be placed on the top of other checkers or on the bottom of the grid.");
	      //Adding buttons to the dialog pane
	      dialog.getDialogPane().getButtonTypes().add(type);
	      //Setting the label
	      return dialog;
	}
}
